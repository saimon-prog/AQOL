---
name: Bug report
about: Signaler un bug dans AQOL
title: "[Bug] "
labels: bug
assignees: ''
---

**Description du bug**
Une description claire et concise de ce qui ne fonctionne pas.

**Pour reproduire**
1. ...
2. ...
3. ...

**Comportement attendu**
Ce qui aurait dû se passer.

**Environnement**
- Version AQOL :
- Python :
- OS :

**Logs / Traceback** (si disponible)
```
```
