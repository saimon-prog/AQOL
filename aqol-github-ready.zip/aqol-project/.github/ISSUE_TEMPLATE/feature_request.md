---
name: Feature request
about: Proposer une amélioration ou une nouvelle fonctionnalité
title: "[Feature] "
labels: enhancement
assignees: ''
---

**Fonctionnalité souhaitée**
Description claire de ce que tu aimerais.

**Cas d’usage**
Dans quel contexte (quantique, labo, calibration…) cette fonctionnalité serait utile ?

**Alternatives envisagées**
As-tu déjà testé d’autres approches ?
